package com.example.cloud;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

import com.google.firebase.iid.FirebaseInstanceIdService;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class FireIDService extends FirebaseMessagingService {
    @Override
    public void onMessageReceived(@NonNull RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        Log.d("Msg", "Message received ["+remoteMessage.getNotification().getBody()+"]");
        // Create Notification
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 1410,
                intent, PendingIntent.FLAG_ONE_SHOT);
        NotificationChannel notificationChannel=null;
        Notification notification=null;
        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)
            notificationChannel = new NotificationChannel("mychanell1", "mychanell1", NotificationManager.IMPORTANCE_HIGH);
        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.O) {
            notification = new Notification.Builder(this, "mychanell1").setContentTitle("Message")
                    .setContentText(remoteMessage.getNotification().getBody())
                    .setChannelId("mychanell1")
                    .setOngoing(false)
                    .setTicker("new notification!")
                    .setSmallIcon(R.drawable.common_full_open_on_phone)
                    .setContentIntent(pendingIntent).build();
        }
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)
            notificationManager.createNotificationChannel(notificationChannel);
        notificationManager.notify(0, notification);

    }
}